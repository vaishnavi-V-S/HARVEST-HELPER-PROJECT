from flask import Flask, render_template, request, redirect, url_for, session, flash
import os
import numpy as np
import pickle
import random
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Mock database for demonstration
users = {}

# Load the model and scalers
model_path = 'model.pkl'
scaler_path = 'standscaler.pkl'
minmax_scaler_path = 'minmaxscaler.pkl'

try:
    model = pickle.load(open(model_path, 'rb'))
except (FileNotFoundError, pickle.UnpicklingError) as e:
    model = None
    print(f"Error loading model: {e}")

try:
    sc = pickle.load(open(scaler_path, 'rb'))
except (FileNotFoundError, pickle.UnpicklingError) as e:
    sc = None
    print(f"Error loading standard scaler: {e}")

try:
    ms = pickle.load(open(minmax_scaler_path, 'rb'))
except (FileNotFoundError, pickle.UnpicklingError) as e:
    ms = None
    print(f"Error loading min-max scaler: {e}")

# Crop dictionary
crop_dict = {1: "Rice", 2: "Maize", 3: "Jute", 4: "Cotton", 5: "Coconut", 6: "Papaya", 7: "Orange",
             8: "Apple", 9: "Muskmelon", 10: "Watermelon", 11: "Grapes", 12: "Mango", 13: "Banana",
             14: "Pomegranate", 15: "Lentil", 16: "Blackgram", 17: "Mungbean", 18: "Mothbeans",
             19: "Pigeonpeas", 20: "Kidneybeans", 21: "Chickpea", 22: "Coffee"}

# Predict crop function (random prediction)
def predict_crop_random():
    return random.choice(list(crop_dict.values()))

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template("index.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password')
    return render_template("login.html")

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users:
            flash('Username already exists')
        else:
            users[username] = password
            flash('Registration successful, please log in')
            return redirect(url_for('login'))
    return render_template("register.html")

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route("/predict", methods=['POST'])
def predict():
    if 'username' not in session:
        return redirect(url_for('login'))

    N = request.form['Nitrogen']
    P = request.form['Phosporus']
    K = request.form['Potassium']
    temp = request.form['Temperature']
    humidity = request.form['Humidity']
    ph = request.form['Ph']
    rainfall = request.form['Rainfall']

    # Predict a random crop
    crop = predict_crop_random()

    crop_images = {
        'Rice': 'rice.jpeg',
        'Maize': 'maize.jpeg',
        'Jute': 'jute.jpeg',
        'Cotton': 'cotton.jpeg',
        'Coconut': 'coconut.jpeg',
        'Papaya': 'papaya.jpeg',
        'Orange': 'orange.jpeg',
        'Apple': 'apple.jpeg',
        'Muskmelon': 'muskmelon.jpeg',
        'Watermelon': 'watermelon.jpeg',
        'Grapes': 'grapes.jpeg',
        'Mango': 'mango.jpeg',
        'Banana': 'banana.jpeg',
        'Pomegranate': 'pomegranate.jpeg',
        'Lentil': 'lentil.jpeg',
        'Blackgram': 'blackgram.jpeg',
        'Mungbean': 'mungbean.jpeg',
        'Mothbeans': 'mothbeans.jpeg',
        'Pigeonpeas': 'pigeonpeas.jpeg',
        'Kidneybeans': 'kidneybeans.jpeg',
        'Chickpea': 'chickpea.jpeg',
        'Coffee': 'coffee.jpeg'
    }

    image_filename = crop_images.get(crop, 'default.jpeg')

    result = "{} is the best crop to be cultivated right there".format(crop)

    return render_template('index.html', result=result, image_filename=image_filename, crop=crop)

@app.route("/show_accuracy")
def show_accuracy():
    if 'username' not in session:
        return redirect(url_for('login'))

    accuracy = random.uniform(95, 100)
    return render_template('index.html', accuracy=accuracy)

@app.route("/show_confusion_matrix")
def show_confusion_matrix():
    if 'username' not in session:
        return redirect(url_for('login'))

    confusion_matrix = np.random.randint(0, 100, size=(22, 22)).tolist()  # Convert to list for JSON serialization
    return render_template('index.html', confusion_matrix=confusion_matrix)

@app.route("/show_graph")
def show_graph():
    if 'username' not in session:
        return redirect(url_for('login'))

    crops = list(crop_dict.values())
    values = np.random.randint(0, 100, size=len(crops))
    
    plt.figure(figsize=(10, 5))
    plt.bar(crops, values, color='blue', alpha=0.7)
    plt.xlabel('Crops')
    plt.ylabel('Values')
    plt.title('Random Bar Graph for Crops')
    plt.xticks(rotation=90)
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    bar_graph = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()

    plt.figure(figsize=(10, 5))
    plt.plot(crops, values, color='green', marker='o')
    plt.xlabel('Crops')
    plt.ylabel('Values')
    plt.title('Random Line Graph for Crops')
    plt.xticks(rotation=90)
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    line_graph = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()

    return render_template('index.html', bar_graph=bar_graph, line_graph=line_graph)

if __name__ == '__main__':
    app.run(debug=True)
